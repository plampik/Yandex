package ru.shanin.yandexweather23.api.config;

public class APIConfigYandexWeather {
    public static final String HOST_URL = "https://api.weather.yandex.ru/v2/imformors/";
    public static final String KEY = "85ff8c78-b074-4026-9a76-6da6a009a790";
}
